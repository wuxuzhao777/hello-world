//
//  singleClass.swift
//  singleClass
//
//  Created by boomsense on 17/3/13.
//  Copyright © 2017年 boomsense. All rights reserved.
//

import UIKit

class singleClass: NSObject {
    
    //结构体方法
    class func shareInstance() ->singleClass{
        struct single{
            static var  singleDeflut = singleClass()
        }
        
        return single.singleDeflut
            
        }
    
    //全局变量方法
    
    static let singleInstance = singleClass()
    
    
    
   //私有化一下
    private override init(){}
    
}
 
