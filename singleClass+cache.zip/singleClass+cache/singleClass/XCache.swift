//
//  XCache.swift
//  singleClass
//
//  Created by boomsense on 17/3/14.
//  Copyright © 2017年 boomsense. All rights reserved.
//

import UIKit

class XCache: NSObject {
    
    //读取文件大小
    static func returnCacheSize() ->String{

        return String(format:"%.2f" ,XCache.forderFileSize(forderpath: NSHomeDirectory()))
    }
    
    //返回文件大小
    static func returnFileSize(path:String) ->Double{
        let manger = FileManager.default
        var filesize:Double = 0
    
        do{
             filesize = try manger.attributesOfItem(atPath: path)[FileAttributeKey.size] as! Double
        } catch {
            
        }
        
        return filesize/1024/124
        
    }
    
    
    //返回子文件大小
    static func forderFileSize(forderpath:String)->Double{
        let manger = FileManager.default
        if !manger.fileExists(atPath: forderpath){
            return 0
        }
        let chiderFilePath = manger.subpaths(atPath: forderpath)
        var fileSize:Double = 0
        for path in chiderFilePath!{
            let SubFilePath = forderpath + "/" + path
            fileSize += XCache.returnFileSize(path: SubFilePath)
        }
        return fileSize
        
    }

    //清除文件
    
    static func cleanCache(competion:()->Void){
            
            XCache.deleteForderFile(forderPath: NSHomeDirectory() + "/Documents")
            
             XCache.deleteForderFile(forderPath: NSHomeDirectory() + "/tmp")
            
             XCache.deleteForderFile(forderPath: NSHomeDirectory() + "/Library")
        
        competion()
        }
    
    //删除文件
        static func deleteFile(path:String){
        let manage = FileManager.default
            do {
                try manage.removeItem(atPath: path)
            } catch  {
                
            }
        
    }
    //找到文件
    static func deleteForderFile(forderPath:String){
        let manage = FileManager.default
        if !manage.fileExists(atPath: forderPath){
         
        }
        
    let childFile = manage.subpaths(atPath: forderPath)
        
        for path in childFile!{
            let filePatch = forderPath + "/" + path
            XCache.deleteFile(path: filePatch)
        }
        
        
        
    
    
    
    }

}
