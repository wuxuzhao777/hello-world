//
//  ViewController.swift
//  singleClass
//
//  Created by boomsense on 17/3/13.
//  Copyright © 2017年 boomsense. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
//    let array = ["","22","333"]
//        
//        let anotherArr = array.map { (string:String) -> Int? in
//          
//            let  length = string.characters.count
//            guard  length > 0 else{
//                return nil
//            }
//            return string.characters.count
//        }
//    
//    print(anotherArr)
//    
//    
//        let Arr3 = array.flatMap { (string:String) -> Int? in
//            
//            let  length = string.characters.count
//            guard  length > 0 else{
//                return nil
//            }
//            return string.characters.count
//        }
//
//    print(Arr3)
        
        
        
        
        
        let length1 = "string".characters.count
        let length2 = "string".data(using: .utf8)?.count
        let length3 = ("string" as NSString).length
    
        print(length1,length2,length3)
        
        let aa = ["11","33","44"]
        
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func readFileSize(_ sender: UIButton) {
        
        
        self.lable.text = XCache.returnCacheSize() + "MB"
    }
    
    @IBAction func CleanFileSize(_ sender: Any) {
        
        XCache.cleanCache { 
        self.lable.text = XCache.returnCacheSize() + "MB"
        }
    }


}

